define({
	status: "検索結果${total}件中${start}件から${end}件までを表示。"
});
