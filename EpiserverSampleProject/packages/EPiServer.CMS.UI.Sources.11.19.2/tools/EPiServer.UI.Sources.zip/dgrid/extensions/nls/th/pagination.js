define({
	status: "${start} - ${end} ของ ${total} ผลลัพธ์",
	gotoFirst: "ไปหน้าแรก",
	gotoNext: "ไปหน้าถัดไป",
	gotoPrev: "ไปหน้าก่อน",
	gotoLast: "ไปหน้าสุดท้าย",
	gotoPage: "ไปหน้า",
	jumpPage: "กระโดดไปหน้า"
});