define({
		status: "${start} - ${end} din ${total} rezultate",
		gotoFirst: "Mergi la prima pagină",
		gotoNext: "Mergi la pagina următoare",
		gotoPrev: "Mergi la pagina precedentă",
		gotoLast: "Mergi la ultima pagină",
		gotoPage: "Mergi la pagina",
		jumpPage: "Sari la pagina"
});