define([
	'intern/node_modules/dojo/has!host-browser?./core/createDestroy',
	'intern/node_modules/dojo/has!host-browser?./core/addCssRule',
	'intern/node_modules/dojo/has!host-browser?./core/setClass',
	'intern/node_modules/dojo/has!host-browser?./core/columns',
	'intern/node_modules/dojo/has!host-browser?./core/stores',
	'intern/node_modules/dojo/has!host-browser?./core/_StoreMixin',
	'intern/node_modules/dojo/has!host-browser?./core/observable',
	'intern/node_modules/dojo/has!host-browser?./core/OnDemand-removeRow',
	'intern/node_modules/dojo/has!host-browser?./plugins/editor',
	'intern/node_modules/dojo/has!host-browser?./plugins/selector',
	'intern/node_modules/dojo/has!host-browser?./plugins/tree',
	'intern/node_modules/dojo/has!host-browser?./plugins/tree-expand-promise',
	'intern/node_modules/dojo/has!host-browser?./extensions/CompoundColumns',
	'intern/node_modules/dojo/has!host-browser?./extensions/Pagination',
	'intern/node_modules/dojo/has!host-browser?./mixins/Keyboard',
	'intern/node_modules/dojo/has!host-browser?./mixins/Selection'
], function(){});