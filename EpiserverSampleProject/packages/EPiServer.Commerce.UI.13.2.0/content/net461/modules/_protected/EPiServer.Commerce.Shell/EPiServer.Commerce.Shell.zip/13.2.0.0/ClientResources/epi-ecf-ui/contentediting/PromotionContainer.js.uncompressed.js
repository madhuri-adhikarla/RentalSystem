require({cache:{
'url:epi-ecf-ui/contentediting/templates/PromotionContainer.html':"<div>\r\n    <div class=\"epi-grid__header\">\r\n        <h1>\r\n            <span data-dojo-attach-point=\"contentTypeNameNode\"></span>\r\n        </h1>\r\n    </div>\r\n    <div class=\"epi-formsHeaderContainer\">\r\n        <h2 data-dojo-attach-point=\"contentTypeDescriptionNode\"></h2>\r\n    </div>\r\n    <ul data-dojo-attach-point=\"containerNode\" class=\"epi-form-container__section\"></ul>\r\n</div>"}});
define("epi-ecf-ui/contentediting/PromotionContainer", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
// epi
    "epi/shell/form/formFieldRegistry",
    "epi/shell/form/Group",
    "epi/shell/layout/SimpleContainer",
    "epi/shell/TypeDescriptorManager",
// resources
    "dojo/text!./templates/PromotionContainer.html"
], function(
// dojo
    declare,
    lang,
    domClass,
// epi
    formFieldRegistry,
    Group,
    SimpleContainer,
    TypeDescriptorManager,
// resources
    template
){
    var module = declare([SimpleContainer], {

        templateString: template,

        contentType: null,

        buildRendering: function(){
            this.inherited(arguments);
            this.set("contentTypeName", this.contentType.name);
            this.set("contentTypeDescription", this._injectSpan(this.contentType.description) || '');
        },

        _setContentTypeNameAttr: { node: "contentTypeNameNode", type: "innerHTML" },

        _setContentTypeDescriptionAttr: { node: "contentTypeDescriptionNode", type: "innerHTML" },

        _injectSpan: function (text) {
            if (!text) {
                return text;
            }

            return lang.replace(text, function (segment, key) {

                if (key === '/') {
                    return '</span>';
                }
                return '<span class="epi-promotion-link epi-promotion--' + key + '">';
            });
        }
    });

    // this must match the "_hint" editor setting defined in GridFormMetadataExtender.cs
    var promotionFormFieldHint = "promotion";

    var addPromotionRegionStyling = function(widget, wrapper) {
        if (widget.promotionRegion) {
            domClass.add(wrapper.domNode, "epi-promotion-block epi-promotion--" + widget.promotionRegion);
        }
    };

    // for regular properties
    formFieldRegistry.add({
        type: formFieldRegistry.type.field,
        hint: promotionFormFieldHint,
        factory: function (widget, parent) {

            var originalFactory = formFieldRegistry.get(widget._type, "");
            var wrapper = originalFactory(widget, parent);

            addPromotionRegionStyling(widget, wrapper);

            return wrapper;
        }
    });

    // for block properties
    formFieldRegistry.add({
        type: formFieldRegistry.type.parent,
        hint: promotionFormFieldHint,
        factory: function (widget, parent) {

            var wrapper = new Group({
                // this class definition is copied from:
                // https://stash.ep.se/projects/SH/repos/episerver-ui/browse/EPiServer.Shell.UI/UI/ClientResources/EPi/shell/layout/SimpleContainer.js?at=ddf71c8c81a4c1f883703eb6f9e3edfeb21dc32a
                "class": "epi-form-container__section__row epi-form-container__section__row--" + widget._type
            });

            addPromotionRegionStyling(widget, wrapper);

            return wrapper;
        }
    });

    return module;
});