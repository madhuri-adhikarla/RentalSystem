﻿define("epi-ecf-ui/contentediting/editors/_RelationCollectionEditorBase", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/when",
    "dojo/aspect",

    // dgrid
    "dgrid/Keyboard",
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/extensions/ColumnResizer",
    "dgrid/extensions/ColumnReorder",

    // EPi Framework
    "epi/dependency",
    "epi/shell/dgrid/Formatter",

    // epi cms
    "epi-cms/contentediting/editors/CollectionEditor",
    "epi-cms/contentediting/editors/model/CollectionEditorModel",
    "epi-cms/core/ContentReference",
    "epi-cms/dgrid/DnD",
    "epi-cms/dgrid/WithContextMenu",

    // commerce
    "./_GridWithDropContainerMixin",
    "./_GridWithItemEditorMixin",
    "./RelationCollectionGridAssembler",
    "../ModelSupport",
     "./LinkEditorDndMixin",
     "../../dgrid/_ClickablePathColumnMixin"
],
function (
    //dojo
    declare,
    lang,
    Deferred,
    when,
    aspect,

    // dgrid
    Keyboard,
    OnDemandGrid,
    Selection,
    ColumnResizer,
    ColumnReorder,

    // EPi Framework
    dependency,
    Formatter,

    // epi cms
    CollectionEditor,
    CollectionEditorModel,
    ContentReference,
    DnD,
    WithContextMenu,

    // commerce
    _GridWithDropContainerMixin,
    _GridWithItemEditorMixin,
    RelationCollectionGridAssembler,
    ModelSupport,
    LinkEditorDndMixin,
    _ClickablePathColumnMixin
) {
    return declare([CollectionEditor, LinkEditorDndMixin, _GridWithDropContainerMixin, _GridWithItemEditorMixin], {

        resources: null,

        itemType: "EPiServer.Commerce.Shell.Rest.Models.RelationModel",

        itemEditorTypes: null,

        storeKey: "epi.commerce.relation",

        commands: CollectionEditorModel.commandMask.remove,

        gridAssemblerType: RelationCollectionGridAssembler,

        gridType: declare([OnDemandGrid, Formatter, Selection, Keyboard, DnD, ColumnResizer, ColumnReorder, WithContextMenu, _ClickablePathColumnMixin]),

        postMixInProperties: function() {
            // summary:
            //      init _store and gridSettings
            // tags:
            //      public override
            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this._store = this._store || registry.get(this.storeKey);

            if (!this.roots) {
                var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors");
                var settings = contentRepositoryDescriptors.catalog;
                this.roots = settings.roots;
            }

            this.gridSettings = lang.mixin(this.gridSettings || {}, {
                useDeleteWithConfirmation: true,
                dndSourceTypes: [ModelSupport.linkTypeIdentifier.relation],
                deleteConfirmationTitle: this.resources.deleteconfirmation.title,
                deleteConfirmationMessage: this.resources.deleteconfirmation.description
            });
        },

        onExecuteDialog: function () {
            var contentLink = this._itemEditor.get("value");
            when(this.getCurrentContext()).then(function(ctx){
                if (ContentReference.compareIgnoreVersion(ctx.id, contentLink)){
                    this.emit("list-error", { errorText: this.resources.addselferror});
                } else {
                    this.model.addItem(this._createItem(contentLink));
                }
            }.bind(this));
        },

        _renderNoDataMessage: function () {
            this.grid.set("noDataMessage", this.resources.nodatamessage);
            this.inherited(arguments);
        },


        _getDialogTitleText: function () {
            return this.resources.addlabel;
        },

        _dndGetItemData: function (item) {
            return when(item.data, function (data) {
                if (data) {
                    return this._createItem(data.contentLink, data.name);
                }
            }.bind(this));
        },

        _createItem: function (targetLink, name) {
            return {
                name: name || targetLink,
                sortOrder: 0,
                source: this.model.get("data"),
                target: targetLink,
                type: this.relationType
            };
        }
    });
});
