﻿define("epi-ecf-ui/widget/viewmodel/CatalogListViewModel", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/string",
// dojox
    "dojox/html/entities",
// epi
    "epi/dependency",
    "epi/shell/selection",
    "epi/shell/command/_CommandProviderMixin",
    "epi/shell/command/withConfirmation",
// epi cms
    "epi-cms/core/ContentReference",
    "epi-cms/command/NewContent",
    "epi-cms/command/DeleteContent",
    "epi-cms/component/ContentContextMenuCommandProvider",
    "epi-cms/component/command/ChangeContext",
    "epi-cms/widget/CreateCommandsMixin",
    "epi-cms/widget/ContentTreeModelConfirmation",
// Commerce
    "epi-ecf-ui/widget/viewmodel/CatalogTreeStoreModel",
    "epi-ecf-ui/component/DeleteCatalogContentHandler",
    "epi-ecf-ui/command/PasteCatalogContent",
// Resources
    "epi/i18n!epi/cms/nls/commerce.components.catalogs.commands",
    "epi/i18n!epi/nls/episerver.shared"
],

function (
// dojo
    array,
    declare,
    lang,
    dojoString,
// dojox
    htmlEntities,
//epi
    dependency,
    Selection,
    _CommandProviderMixin,
    withConfirmation,
// epi cms
    ContentReference,
    NewContent,
    DeleteContent,
    ContextMenuCommandProvider,
    ChangeContextCommand,
    CreateCommandsMixin,
    ContentTreeModelConfirmation,
// Commerce
    CatalogTreeStoreModel,
    DeleteCatalogContentHandler,
    PasteCatalogContent,
// Resources
    res,
    sharedResources
) {
    // module:
    //      epi-ecf-ui.widget.viewmodel.CatalogListViewModel

    return declare([_CommandProviderMixin, CreateCommandsMixin], {

        // summary:
        //    Represents the catalog list overview widget's model.
        // model:
        //    "epi-ecf-ui/widget/viewmodel/CatalogListViewModel"
        // tags:
        //    public

        model: null,

        treeStoreModel: null,

        clipboardManager: null,

        selection: null,

        numSelectedRows: null,

        _commandRegistry: null,

        postscript: function () {
            // make sure clipboard is shared across widgets
            this.clipboardManager = this.clipboardManager || dependency.resolve("epi.commerce.global").get("epi.commerce.global.clipboard");

            this.selection = this.selection || new Selection();
            this.repositoryKey = "catalog";

            this.inherited(arguments);

            this.treeStoreModel = new CatalogTreeStoreModel();
            this.treeStoreModel.roots = this.roots;

            this._commandRegistry = this._commandRegistry || {
                sort: function () {
                    var commands = [];
                    for (var key in this) {
                        if (key !== "toArray" && key !== "sort" && this.hasOwnProperty(key) && key !== "pasteOnContext") {
                            var index = this[key].order;
                            if (!index) {
                                index = 100;
                            }
                            commands.push([index, this[key].command]);
                        }
                    }

                    commands.sort(function (a, b) {
                        return a[0] - b[0];
                    });

                    return commands;
                },
                toArray: function () {
                    var sortedCommand = this.sort();
                    var commands = [];
                    array.forEach(sortedCommand, function (key) {
                        commands.push(key[1]);
                    });

                    return commands;
                }
            };

            this._setupCommands();
        },

        _setupCommands: function () {

            var commandSettings = {
                category: "context",
                clipboard: this.clipboardManager,
                selection: this.selection,
                model: this.treeStoreModel
            };

            lang.mixin(this._commandRegistry, this.getCreateCommands());
            lang.mixin(this._commandRegistry, {
                edit: {
                    command: new ChangeContextCommand({
                        category: "context",
                        forceContextChange: true,
                        viewName: "formedit"
                    }),
                    order: -1
                },
                paste: {
                    command: new PasteCatalogContent(commandSettings),
                    order: 103
                },
                deleteCatalog: {
                    command: new DeleteContent(commandSettings),
                    order: 104
                }
            });
            this.set("commands", this._commandRegistry.toArray());
        },

        _modelSetter: function (model) {
            this.model = model;
            if (!model) {
                return;
            }

            var modelData = model.data || model;
            this._commandRegistry.edit.command.set("model", modelData);

            if (this._commandRegistry.deleteCatalog) {
                // add confirmation dialog for delete content command
                this._updateDeleteCommand(this._commandRegistry.deleteCatalog.command, modelData[0]);
            }

            // set model for create commands, to update command's canExecute
            for (var cmd in this._commandRegistry) {
                var command = this._commandRegistry[cmd].command || {};
                if (command instanceof NewContent || command.popup) {
                    command.set("model", modelData);
                }
            }
            this.updateSelection(modelData);
        },

        updateSelection: function (selectionData) {
            var selection = [];
            if (selectionData) {
                this.numSelectedRows = selectionData.length;
                selection = array.map(selectionData, function (item) {
                    // Navigate content tree use content without work id. So should set selection data with context id in unspecific version reference.
                    var contextIdWithoutVersion = this.model ? new ContentReference(this.model.contextId).createVersionUnspecificReference().toString() : null;
                    return { type: "epi.cms.contentdata", data: item, contextId: contextIdWithoutVersion };
                }, this);
            }

            if (this.selection) {
                this.selection.set("data", selection);
            }
        },

        _updateDeleteCommand: function (command, model) {
            // summary:
            //      Update delete command, to show a confirmation dialog.
            // tags:
            //      protected

            if (!model) {
                return;
            }

            // since execute function will be modify in withConfirmation, we must back it up.
            if (!command._originalExecute) {
                // keep original execute function
                command._originalExecute = command._execute;
            } else {
                // rollback execute function
                command._execute = command._originalExecute;
            }

            // make sure the input object is un-touched by creating a cloned object, then modify the name property.
            var clonedObject = lang.clone(model);
            clonedObject.name = htmlEntities.encode(clonedObject.name || "");
            var setting = {
                iconClass: "epi-iconWarning epi-icon--large epi-icon--colored",
                title: res.deletecatalogconfirmationtitle,
                description: dojoString.substitute(res.deletecatalogconfirmationdescription, clonedObject),
                confirmActionText: res.deletecatalogconfirmationlabel,
                cancelActionText: sharedResources.action.cancel,
                setFocusOnConfirmButton: false // make Delete button gray
            };

            command = withConfirmation(command, DeleteCatalogContentHandler, setting);
        },

        destroy: function(){
            this.treeStoreModel.destroy();
            delete this.treeStoreModel;
        }
    });
});